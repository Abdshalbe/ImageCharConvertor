package image_char_matching;

import image_char_matching.RoundingStratgie.RounderFactory;
import image_char_matching.RoundingStratgie.RoundingKeyStrategy;

import java.util.*;
import static image_char_matching.CharConverter.convertToBoolArray;

/**
 * SubImgCharMatcher class
 * responsible for matching an ASCII char to a brightness value
 * */
public class SubImgCharMatcher {
    private static final double CHAR_ARR_SIZE = 256;
    private static final String DEFAULT = "abs";
    private final  TreeSet<Character> MappedChars = new TreeSet<>();
    private final Map<Double, Character>  brightnessToCharMap = new HashMap<>();
    private final TreeMap<Double, Character> charTreeMap = new TreeMap<>();
    private  RoundingKeyStrategy roundingKeyStrategy;
    private final RounderFactory rounderFactory;
    private double maxBright;
    private double minBright;
    private final TreeMap<Double, Character> brightnessToCharTreeMap = new TreeMap<>();

    /**
     * constructor for SubImgCharMatcher class
     * @param charset the charset to be used for matching
     * */
    public  SubImgCharMatcher(char[] charset) {
        rounderFactory = new RounderFactory(this);
        this.roundingKeyStrategy =  rounderFactory.createRounder(DEFAULT) ;
        for(char c : charset) {
            if(!MappedChars.contains(c)){
                MappedChars.add(c);
                charTreeMap.put(calculateBrightness(c),c);
            }
        }
        createBrightnessToCharMap();
    }

    /**
     * getCharByImageBrightness method responsible for let as the matching char
     * for specific brightness
     * @param brightness the brightness value to be matched
     * @return char that matches the brightness value
     * */
    public char getCharByImageBrightness(double brightness) {
        double newBrightness = roundingKeyStrategy.round(brightness);
        return brightnessToCharMap.get(newBrightness);
    }

    /**
     * addChar method responsible for adding a char to the charset and map
     * @param c the char to be added
     * */
    public void addChar(char c) {
        if(!MappedChars.contains(c)){
            MappedChars.add(c);
            double brightness = calculateBrightness(c);
            charTreeMap.put(brightness,c);
            if (brightness > maxBright||brightness < minBright) {
                createBrightnessToCharMap();
            }else{
                double newBrightness = (brightness - minBright) / (maxBright - minBright);
                brightnessToCharMap.put(newBrightness,c);
                brightnessToCharTreeMap.put(newBrightness,c);
            }
        }
    }

    /**
     * getCharset method responsible for returning the charset
     * @param c char to be removed
     * */
    public void removeChar(char c) {
        if(MappedChars.contains(c)){
            double brightness = calculateBrightness(c);
            MappedChars.remove(c);
            charTreeMap.remove(brightness);
            brightness = (brightness - minBright) / (maxBright - minBright);
            brightnessToCharMap.remove(brightness);
            brightnessToCharTreeMap.remove(brightness);
            if(brightness == maxBright || brightness == minBright){
                createBrightnessToCharMap();
            }
        }
    }

    /**
     * setRounder method responsible for setting the rounding strategy
     * @param rounderName the name of the rounding strategy
     * (abs, ceil, floor)
     * */
    public void setRounder(String rounderName){
        this.roundingKeyStrategy =  rounderFactory.createRounder(rounderName) ;
    }

    /**
     * getClosestKey method responsible for returning the closest key value
     * */
    public double[] getClosestKey(double value) {
        Double floor = brightnessToCharTreeMap.floorKey(value);   // Greatest key <= value
        Double ceiling = brightnessToCharTreeMap.ceilingKey(value); // Smallest key >= value

        double floorVal = (floor != null) ? floor : -1;
        double ceilingVal = (ceiling != null) ? ceiling : -1;

        return new double[]{floorVal, ceilingVal};
    }

    /**
     * getMappedChars method responsible for returning the charset
     * @return the charset
     * */
    public Set<Character> getMappedChars() {
        return MappedChars ;
    }

    /**
     * createBrightnessToCharMap method responsible for creating the map
     * between brightness and char
     * */
    private void createBrightnessToCharMap() {
        minBright = charTreeMap.firstKey();
        maxBright = charTreeMap.lastKey();
        for (Double  brightness : charTreeMap.keySet()) {
            double normalizedBrightness = (brightness - minBright) / (maxBright - minBright);
            char  c = charTreeMap.get(brightness);
            brightnessToCharMap.put(normalizedBrightness, c);
            brightnessToCharTreeMap.put(normalizedBrightness, c);
        }
    }

    /**
     * calculateBrightness method create the double
     * brightness value for a specific char
     * @param c the char to be converted
     * @return the brightness value of the char
     * */
    private double calculateBrightness(char c){
        boolean[][] charArray = convertToBoolArray(c);
        double brightness = 0;
        for (boolean[] booleans : charArray) {
            for (boolean aBoolean : booleans) {
                brightness += aBoolean ? 1 : 0;
            }
        }
        return brightness/CHAR_ARR_SIZE;
    }
}
