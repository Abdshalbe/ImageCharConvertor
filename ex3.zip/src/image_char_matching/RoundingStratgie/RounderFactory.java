package image_char_matching.RoundingStratgie;

import image_char_matching.SubImgCharMatcher;

public class RounderFactory {
    private final SubImgCharMatcher subImgCharMatcher;

    public RounderFactory(SubImgCharMatcher subImgCharMatcher) {
        this.subImgCharMatcher = subImgCharMatcher;
    }

    public RoundingKeyStrategy createRounder(String roundingStrategy) {
        return switch (roundingStrategy) {
            case "upper" -> new FloorRoundStrategic(subImgCharMatcher);
            case "lower" -> new CeilRoundStrategic(subImgCharMatcher);
            case "abs" -> new RounderAbs(subImgCharMatcher);
            default -> null;
        };
    }
}
