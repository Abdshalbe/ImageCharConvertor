package image_char_matching.RoundingStratgie;

import image_char_matching.SubImgCharMatcher;

public class FloorRoundStrategic implements RoundingKeyStrategy{
    private final SubImgCharMatcher subImgCharMatcher;

    public FloorRoundStrategic(SubImgCharMatcher subImgCharMatcher) {
        this.subImgCharMatcher = subImgCharMatcher;
    }

    @Override
    public double round(double value) {
        double [] keys = subImgCharMatcher.getClosestKey(value);
        if(keys[1]!=-1){
            return keys[1];
        }
        return keys[0];
    }
}
