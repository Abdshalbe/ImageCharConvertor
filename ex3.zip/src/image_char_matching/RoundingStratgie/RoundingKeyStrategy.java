package image_char_matching.RoundingStratgie;

public interface RoundingKeyStrategy {
    double round(double value);
}
