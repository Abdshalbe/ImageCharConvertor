package image_char_matching.RoundingStratgie;


import image_char_matching.SubImgCharMatcher;

public class RounderAbs implements RoundingKeyStrategy{
    private final SubImgCharMatcher subImgCharMatcher;

    public RounderAbs(SubImgCharMatcher subImgCharMatcher) {
        this.subImgCharMatcher = subImgCharMatcher;
    }

    @Override
    public double round(double value) {
        double [] keys = subImgCharMatcher.getClosestKey(value);
        if (keys[0] == -1) return keys[1];
        if (keys[1] == -1) return keys[0];
        return (Math.abs(value - keys[0]) <= Math.abs(keys[1] - value)) ? keys[0] : keys[1];
    }
}
