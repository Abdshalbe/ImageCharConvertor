package ascii_output;

public class OutputFactory {
    public static AsciiOutput createOutput(String outputType) {
        return switch (outputType) {
            case "html" -> new HtmlAsciiOutput("out.html", "Courier New");
            case "console" -> new ConsoleAsciiOutput();
            default -> null;
        };
    }
}
