package ascii_art;

import ascii_output.AsciiOutput;
import ascii_output.OutputFactory;

import java.io.IOException;
import java.util.function.Consumer;



public class Shell {
    private static final int DEFAULT_RES = 2;
    private static final char[] STARTING_CHARS = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    private static final int MAX_CHAR = 127;
    private static final int MIN_CHAR = 32;
    private static final int LAST_INDEX = 2;
    private static final int INCREASE_FACTOR = 2;
    private static final float DECREASE_FACTOR = 0.5f;

    private final AsciiArtAlgorithm asciiArtAlgorithm;

    public static void main(String[] args){
//        if (args.length != 1) {
//            System.err.println("Usage: java ascii_art.Shell <image path>");
//            System.exit(1);
//        }
//
//        try {
//            Shell shell = new Shell(args[0]);
//            shell.run();
//        } catch (IOException e) {
//            System.err.println("Failed to load image or initialize ASCII art algorithm: " + e.getMessage());
//            System.exit(1);
//        }
        try {
            Shell shell = new Shell("examples (2)/cat.jpeg");
            shell.run();
        }catch (IOException e) {
            System.err.println("Failed to load image or initialize ASCII art algorithm: " + e.getMessage());
        }
    }

    public Shell(String imageName) throws IOException {
        this.asciiArtAlgorithm = new AsciiArtAlgorithm(imageName, STARTING_CHARS
                , DEFAULT_RES);
    }

    public void run() {
        String input;
        System.out.println("Enter a command (exit, chars, add, remove," +
                " res, output, round, asciiArt):");
        while (true) {
            System.out.print(">>> ");
            input = KeyboardInput.readLine();

            if (input.startsWith("exit")) {
                System.out.println("Exiting...");
                return;
            } else if (input.startsWith("chars")) {
                for (Character c : asciiArtAlgorithm.getCharSet()) {
                    System.out.print(c.charValue() + " ");
                }
            }else if (input.startsWith("add")) {
                String value =input.substring(3).trim();
                handleChars(value, asciiArtAlgorithm::addChar,"add");
            }else if (input.startsWith("remove")) {
                String value =input.substring(7).trim();
                handleChars(value, asciiArtAlgorithm::removeChar,"remove");
            }else if (input.startsWith("res")) {
                handleResolution(input);
            }
            else if (input.startsWith("output")) {
                String value =input.substring(7).trim();
                if(!asciiArtAlgorithm.setRenderer(value)) {
                    System.out.println("Did not output method due to incorrect format.");
                }
            }else if (input.startsWith("round")) {
                String value =input.substring(6).trim();
                if (value.startsWith("up")) {
                    asciiArtAlgorithm.setRounder("upper");
                }else if (value.startsWith("down")) {
                    asciiArtAlgorithm.setRounder("lower");
                }else if (value.startsWith("abs")) {
                    asciiArtAlgorithm.setRounder("abs");
                }else{
                    System.out.println("Did not change rounding method due to incorrect format.");
                }
            }else if (input.startsWith("asciiArt ")) {
                if(asciiArtAlgorithm.getCharSet().size() <= 1) {
                    System.out.println("Did not execute. Charset is too small. ");
                }
                asciiArtAlgorithm.getRenderer().out(asciiArtAlgorithm.run());
            }

        }
    }

    private void handleResolution(String input) {
        String value = input.substring(3).trim();
        if (value.startsWith("up")) {
            boolean changed = asciiArtAlgorithm.changeResolution(INCREASE_FACTOR);
            if (changed) {
                System.out.println("Resolution set to " + asciiArtAlgorithm.getResolution());
            } else {
                System.out.println("Did not change resolution due to incorrect format.");
            }
        } else if (value.startsWith("down")) {
            boolean changed = asciiArtAlgorithm.changeResolution(DECREASE_FACTOR);
            if (changed) {
                System.out.println("Resolution set to " + asciiArtAlgorithm.getResolution());
            } else {
                System.out.println("Did not change resolution due to incorrect format.");
            }
        } else if (value.isEmpty()) {
            System.out.println("Resolution set to " + asciiArtAlgorithm.getResolution());
        } else {
            System.out.println("Did not change resolution due to incorrect format.");
        }
    }

    /**
     * handles the input for the add and remove commands
     * @param input the input from the user
     * @param charAction the action to be performed on the input
     * */
    private void handleChars(String input, Consumer<Character> charAction,String funcName) {
        if (input.length() == 1) {
            charAction.accept(input.charAt(0));
        } else if (input.startsWith("all")) {
            for (int i = MIN_CHAR; i < MAX_CHAR; i++) {
                charAction.accept((char) i);
            }
        } else if (input.startsWith("space")) {
            charAction.accept(' ');
        }else if (input.matches(".-.")) {
            char start = input.charAt(0);
            char end = input.charAt(LAST_INDEX);
            if (start <= end) {
                for (char c = start; c <= end; c++) {
                    charAction.accept(c);
                }
            } else {
                for (char c = start; c >= end; c--) {
                    charAction.accept(c);
                }
            }
        }else {
            System.out.format("Did not %s due to incorrect format." ,funcName);
        }
    }

}
